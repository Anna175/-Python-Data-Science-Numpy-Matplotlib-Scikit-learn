#!/usr/bin/env python
# coding: utf-8

# # 1

# In[1]:


import numpy as np


# In[2]:


a = np.array ([[1, 6],
               [2, 8],
               [3, 11],
               [3, 10],
               [1, 7]])


# In[3]:


mean_a = np.array (a)


# In[4]:


mean_a


# In[5]:


mean_a.mean(axis = 0)


# # 2

# In[6]:


a_centered = a - mean_a.mean(axis = 0, keepdims = True)


# In[7]:


a_centered


# # 3

# In[13]:


a_centered_sp = np.dot(a_centered[:,0],a_centered[:,1])


# In[14]:


a_centered_sp


# In[11]:


a_centered_sp/(a.shape[0] - 1)


# # 4

# In[15]:


m = a.transpose ()


# In[16]:


m


# In[17]:


np.cov(m)


# # 1.1

# In[4]:


import numpy as np
import pandas as pd


# In[5]:


authors = pd.DataFrame ({'author_id': [1,2,3], 'author_name': ['Тургенев', 'Чехов', 'Островский']}, 
                       columns = ['author_id', 'author_name'])


# In[8]:


authors


# In[9]:


book = pd.DataFrame ({'author_id': [1, 1, 1, 2, 2, 3, 3], 'book_title': ['Отцы и дети', 'Рудин', 'Дворянское гнездо', 'Толстый и тонкий', 'Дама с собачкой', 'Гроза', 'Таланты и поклонники'], 'price': [450, 300, 350, 500, 450, 370, 290]}, 
                       columns = ['author_id', 'book_title', 'price'])


# In[10]:


book


# # 1.2

# In[11]:


authors_price = pd.merge(authors, book, on = 'author_id', how = 'left')


# In[12]:


authors_price


# # 1.3

# In[13]:


authors_price.nlargest(5, 'price')


# # 1.4

# In[44]:


authors_stat1 = authors_price.groupby('author_name').agg({'price':'max'}).rename(columns={'price':'max_price'})


# In[47]:


authors_stat2 = authors_price.groupby('author_name').agg({'price':'min'}).rename(columns={'price':'min_price'})


# In[57]:


authors_stat3 = authors_price.groupby('author_name').agg({'price':'mean'}).rename(columns={'price':'mean_price'})


# In[55]:


authors_stat = pd.concat([authors_stat1, authors_stat2, authors_stat3], axis = 1) 


# In[56]:


authors_stat


# In[58]:


df1 = pd.DataFrame({'cover':['твердая', 'мягкая', 'мягкая', 'твердая', 'твердая', 'мягкая', 'мягкая']}, columns=['cover']) 
authors_price = pd.concat([authors_price, df1], axis = 1) 
authors_price


# In[59]:


get_ipython().run_line_magic('pinfo', 'pd.pivot_table')


# In[60]:


book_info = pd.pivot_table(authors_price, values='price', index=['author_name'], 
columns=['cover'], aggfunc=np.sum, fill_value=0) 
book_info 


# In[61]:


book_info.to_pickle('book_info.pkl') 


# In[62]:


book_info2 = pd.read_pickle('book_info.pkl') 


# In[63]:


book_info==book_info2 


# In[ ]:




